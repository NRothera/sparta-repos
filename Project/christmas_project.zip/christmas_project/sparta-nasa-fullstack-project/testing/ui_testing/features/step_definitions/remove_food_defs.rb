Then("I should be able to click the delete button") do
  show_page.click_delete_button
end
