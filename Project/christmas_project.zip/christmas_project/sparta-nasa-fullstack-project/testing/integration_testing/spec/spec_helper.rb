require_relative '../lib/nasa_httparty'

RSpec.configure do |config|
  config.formatter = :documentation
end
